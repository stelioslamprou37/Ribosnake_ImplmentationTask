Alpha correlation analysis plot for all numerical metadata values. Also including test statistics for the spearman analysis.
Plot shows the diversity, calculated with the chosen metric, for different metadata-column data.
Values of the spearman test indicate whether the different diversity metrics are significantly different based on the chosen metadata.