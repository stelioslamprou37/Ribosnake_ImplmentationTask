Link to the qiime-view of the beta-rarefaction information. It includes an EMPeror plot depicting the differences between the samples concerning different
characteristics of the samples with the help of PCoA. In addition to that it holds a heatmap depicting the euclidean-Mantel correlation between iterations and the possibility
to download a Newick-tree of the species found in the samples.