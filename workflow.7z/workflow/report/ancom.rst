Volcano plot from Ancom analysis.
Ancom analysis was done for the chosen metadata column.
Ancom creates a feature importance analysis plot, showing which features show significant changes over the analysed metadata column data.
Output are the bacterial genera with significant changes as well as percentile abundances for the significant changes.
