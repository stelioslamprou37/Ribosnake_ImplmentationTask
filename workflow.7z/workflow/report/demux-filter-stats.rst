Statistics showing total reads, reads after initial filtering and number of truncated reads because of length or quality.
These statistics are calculated right after pairing the reads and trimming.