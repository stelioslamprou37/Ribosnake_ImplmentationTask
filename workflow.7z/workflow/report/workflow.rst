for 16S rDNA analysis.
