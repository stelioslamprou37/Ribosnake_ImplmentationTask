Interactive feature volatility plot, depicting the change of the different bacterial genera depending on the
continuous variable used for analysis. Examples for this are time or temperature.