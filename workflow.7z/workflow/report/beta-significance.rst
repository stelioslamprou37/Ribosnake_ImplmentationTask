Beta significance boxplot for samples and groups.
Depicted are the distances between the samples clustered based on the different metadata information.
Statistical testing was done with PERMANOVA test.