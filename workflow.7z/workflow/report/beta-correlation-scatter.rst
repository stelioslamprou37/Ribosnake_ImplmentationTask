Beta correlation scatter plot.
Analysis shows the compared pairwise diversity metrics based on the chosen diversity metrics.
Mantel test values show if the pairwise diversity changes are significant.