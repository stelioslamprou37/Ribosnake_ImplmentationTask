Empress tree-viewer for visualizing the tree built with MAFFT. Several customizations are possible, like changing the color of the branches and 
adding metadata as barplots.