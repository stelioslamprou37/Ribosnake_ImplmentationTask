A heatmap depicting the distance matrix created based on the chosen metadata column and metric.
The lighter the color, the bigger the distance between the samples. 