Heatmap showing the bacterial genera found in the different samples. The bacteria are characterized on genus level. 
The frequency of the different genera in one sample is depicted on a logarithmic scale.
